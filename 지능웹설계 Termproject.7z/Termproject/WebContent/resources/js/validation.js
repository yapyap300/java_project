function CheckAddguest(){
	
	var id = document.getElementById("id");
	var passwd = document.getElementById("passwd");
	
	if(id.value==""){ 
		alert("아이디를 입력해 주세요."); 
		document.regFrm.id.focus(); 
		return; 
	} 
	if(passwd.value==""){ 
		alert("비밀번호를 입력해 주세요."); 
		document.regFrm.pwd.focus(); 
		return; 
	}

	
	document.join.submit()
}